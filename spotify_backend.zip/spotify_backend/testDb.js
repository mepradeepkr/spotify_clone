const mongoose = require("mongoose");
const connectionString = "mongodb+srv://gpu4ml:WM0VbDTKjNjZitgZ@cluster0.qkjnb9c.mongodb.net/?retryWrites=true&w=majority";
const options = { autoIndex: true };

const connectToDB = async () => {
  try {
    await mongoose.connect(connectionString, options);
    console.log("Connected to MongoDB Atlas");
  } catch (error) {
    console.error(error);
  }
};
const express = require("express");
const User = require("../models/User");
const bcrypt = require("bcrypt");
const {getToken} = require("../utils/helpers");



const router = express.Router(); //only route functinsality is used,


//this post write will help you to register a user;
router.post("/register", async (req, res) => {
    //This code is run when the /register api is called as a POST request
    //reqest body
    // My req.body will be of the format ( email, password, firstName, lastName, username )

    const { email, password, firstName, lastName, username } = req.body;

    //step 2 : Does a user with this email already exist? If yes, throw an error;
    const user = await User.findOne({email:email}); //asynchornous funciton when await used'
    if( user ){
        // status code by default is 200 res.json(error:"message")
        return res
            .status(403)
            .json({error:"A user with this email alredy exists."});
    }
    // This is a valid request

    // Step 3 : Create a new user in the DB
    // Step 3.1 : We do not store password in plain text;
    // password : convert plainText password to hash,

    const hashedPassword = (await bcrypt.hash(password, 10)).toString();
    const newUserData = {
        email,
        password : hashedPassword,
        firstName, 
        lastName,
        username,
    };
    const newUser = await User.create( newUserData );

    // console.log( (await hashedPassword).toString() + " "+ password );

    // Step 4: We want to create the token to return to the user;
    const token = await getToken(email, newUser); // getToken fucntion present in "utils.helpers". folder

    // step 5: Return the result to the user
    const userToReturn = { ...newUser.toJSON(), token };
    delete userToReturn.password;

    return res.status(200).json(userToReturn);
});

router.post("/login", async (req, res) => {
    // step 1 : Get email and password set by user from req.body
    const {email, password} = req.body;
    // step 2 : Check if a user with the given email exist. if not , the credentials are invalid
    const user = await User.findOne({email: email});

    if( !user ){
        return res.status(403).json({err:"Invalid credentials"});
    }
    // step 3 : if the user exits , check if the password is correct, if not, then credentials error
    // this is tricky, the original password is stored as a hash.
    // bcript .care enalble us to passwrd given by user to a hash password;
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if( !isPasswordValid ){
        return res.status(403).json({err:"Invalid credentials"});
    }
    // step 4 : if the credentials are correct resuturn a token to user.
    const token = await getToken( user.email, user);
    const userToReturn = {...user.toJSON(), token};
    delete userToReturn.password;
    return res.status(200).json(userToReturn);
});
module.exports = router;
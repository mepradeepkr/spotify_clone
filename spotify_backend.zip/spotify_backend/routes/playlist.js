const express = require("express");
const passport = require("passport");
const Playlist = require("../models/Playlist");
const User = require("../models/User");
const Song = require("../models/Song")

const router = express.Router();

// route 1: Create a playlist
router.post(
    "/create",
    passport.authenticate("jwt", {session: false}),
    async (req, res) => {
        const currentUser = req.user;
        const {name, thumbnail, songs} = req.body;
        if(!name || !thumbnail || !songs){
            return res.status(301).json({err: "Insufficient data"});
        }
        const playlistData = {
            name,
            thumbnail,
            songs,
            owner: currentUser._id,
            collaborators: [],
        };
        const playist = await Playlist.create(playlistData);
        return res.status(200).json(playist);
    }
);



// route2: Get a playlist by ID;
// we will get a playlist ID as a route parameter and return the playlist having that id;
// /something1/something2/something2 --> exact match 
// playlist/get/:playlistId --> playlistId is variable()
// /playlist/get/coolSongs --> playlistId is assigned as "coolsongs"

router.get(
    "/get/playlist/:playlistId",
    passport.authenticate("jwt", {session:false}),
    async (req, res)=>{
        // this concept is called req.params
        const playlistId = req.params.playlistId; // /playlist/get/playlist/coolSongs 
        // I need to find the playlist with the _id = playlistId
        const playlist = await Playlist.findOne({_id:playlistId}).populate({
            path : "songs",
            populate : {
                path : "artist",
            }
        });
        if(!playlist){
            return res.status(404).json({err:"invalid ID"});
        }
        return res.status(200).json(playlist);
    }
);

// Get all playlist made by an artist;
router.get("/get/artist/:artistId",
    passport.authenticate("jwt", {session : false}),
    async (req, res) => {
        const artistId = req.params.artistId;
        //error hadling can be possible
        const artist = await User.findOne({_id: artistId});
        if(!artist){
            return res.status(304).json({err:"Invalid Artist ID"});
        }
        const playists = await Playlist.find({owner:artistId});
        return res.status(200).json({data: playists});
    });

//get all plalylist by me;
// route :  /get/me
router.get(
    "/get/me",
    passport.authenticate("jwt", {session: false}),
    async (req, res) => {
        const artistId = req.user._id;
        const playlists = await Playlist.find({owner:artistId}).populate(
            "owner"
        );
        return res.status(200).json({data: playlists});
    }
);




// Add a song to a playlist
router.post(
    "/add/song",
     passport.authenticate("jwt", {session:false}),
     async (req, res)=> {
        const currentUser = req.user;
        const {playlistId, songId} = req.body;
        // step 0 : get the playlist if exists;
        const playlist = await Playlist.findOne({_id: playlistId});
        if( !playlist ){
            return res.status(304).json({err:"Playlist does not exist"});
        }

        console.log(playlist);
        console.log(currentUser);
        console.log(playlist.owner);
        console.log(currentUser._id);
        console.log(typeof(currentUser._id));
        console.log( playlist.owner == currentUser._id); // string can be campared but comparing object will return false;
        console.log(playlist.owner.equals(currentUser._id));

        //step 1 : check if current user owns the playlist or a in collaborators;
        if( !playlist.owner.equals(currentUser._id) &&
            !playlist.collaborators.includes(currentUser._id) ){
                return res.status(400).json( {err : "Not allowed"} );
            }
        // step 2 Check if the song is a valid song;
        const song = await Song.findOne({_id: songId})
        if(!song){
            return res.status(304).json({err:"Song Does not exits"});
        }
        // Step 3: We can now simply add the song to the playlist
        playlist.songs.push(songId);
        await playlist.save();

        return res.status(200).json(playlist);
     });
module.exports = router;
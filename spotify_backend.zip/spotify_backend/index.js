// npm init : package.json -- this is node projec
// npn i express : expressJs package install hogya;
// we finally use express
// mongoose can be used to connect mongo db with nodeJS
const express = require("express");
const mongoose = require("mongoose");
const app = express();
require("dotenv").config();
var JwtStrategy = require('passport-jwt').Strategy,
    ExtractJwt = require('passport-jwt').ExtractJwt;
const passport = require("passport");
const User = require("./models/User");

const authRoutes = require("./routes/auth");
const songRoutes = require("./routes/song");
const playlistRoutes = require("./routes/playlist");

const cors = require("cors"); // server is allowd to be accesed by specific urls only we are bypassing that for now. by using cors
app.use(cors());

const port = 8000;

app.use(express.json()); //now req.body will always be a json;

// console.log(process.env.MONGO_PASSWORD);


//connect monogo db to node app;
// two args , 1. which DB to connect to db.URL, 2, connections options

// const db_uri = "mongodb+srv://gpu4ml:" +
//                     process.env.MONGO_PASSWORD + 
//                     "@cluster0.wwkbqih.mongodb.net/?retryWrites=true&w=majority";


// ai9333 gpu4ml
// const db_uri = "mongodb+srv://"+process.env.MONGO_USERNAME+":"+process.env.MONGO_PASSWORD+"@cluster0.qkjnb9c.mongodb.net/?retryWrites=true&w=majority"
const db_uri = "mongodb://localhost:27017"

// ai69 gpu4game
// const db_uri = "mongodb+srv://"+process.env.MONGO_USERNAME+":"+process.env.MONGO_PASSWORD+"@cluster0.klay4et.mongodb.net/?retryWrites=true&w=majority"
mongoose.connect(db_uri, 
                {
                    useNewUrlParser:true,
                    useUnifiedTopology:true,
                }
            )
            .then((x)=> {
                console.log("Connected to Mongo")
            })
            .catch((error) => {
                console.log("Error in Connecting to Mongo"+error);
            });

//setup passport-jwt

let opts = {}
opts.jwtFromRequest = ExtractJwt.fromAuthHeaderAsBearerToken();
opts.secretOrKey = 'thisKeyIsSupposedToBeSecret'; // it is secret key, 
passport.use(
    new JwtStrategy(opts, function(jwt_payload, done) {
        User.findOne({_id: jwt_payload.identifier}, function(err, user) {
            // done(error, doesTheUserExist)
            if (err) {
                return done(err, false);
            }
            if (user) {
                return done(null, user);
            } else {
                return done(null, false);
                // or you could create a new account
            }
        });
    }));



// API : GET type / : return text "Hello world"
app.get("/", (req, res) => {
    // req contains all data for request
    // res contains all data for the response;
    res.send("Hello World");
});

app.use("/auth", authRoutes); // full path will be ./auth/register to input user
app.use("/song", songRoutes);
app.use("/playlist", playlistRoutes);

// Now we wnt to tell express that our local host runninng on 8000;
app.listen(port, ()=> {
    console.log("App is running on port : "+port );
});




